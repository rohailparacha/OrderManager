<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; {{ now()->year }} - Order Management Dashboard
        </div>
    </div>
    <div class="col-xl-6">
        
    </div>
</div>